Euan Botha u21439631
docker build -t u21439631 .
docker run --name u21439631 -p 3000:3000 u21439631
docker stop u21439631
docker rm u21439631